<template>
<header>

    <div id="header_wrap">
        <div class="menu">
            <nav>
                <router-link to="/">Home</router-link> |
                <router-link to="/getHopeBooks">희망도서목록</router-link> |
            </nav>
        </div>
        <div class="title">
            <h3>한국 도서관 - 도서 대여 서비스</h3>
        </div>
        <div style="text-align:center; margin:30px; display:flex; justify-content:center; align-items:center">
            <p><span id="wicon"><img src="" /></span></p>
            <p style="margin:0 10px">(<span id="weather"></span>)</p>
            <p style="margin:0 10px">최저기온: <span id="mintemp"></span></p>
            <p style="margin:0 10px">최고기온: <span id="maxtemp"></span></p>
            <p style="margin:0 10px">습도 : <span id="humidity"></span></p>
        </div>
    </div>
</header>
</template>

<script>
    export default {
            name:'Header'
    }
</script>

<style scoped>
header {
	width: 100%;
	background-color: #fff;
	border-bottom: 1px solid #d9d9d9;
	}

#header_wrap {
	max-width: 1200px;
	margin: 0 auto;
	}

#header_wrap .menu {
	height: 30px;
	line-height: 30px;
	border-bottom: 1px solid #d9d9d9;
	}

#header_wrap .menu nav {
	display:flex; justify-content:flex-end;
	}

#header_wrap .menu nav a {
	margin-right: 5px;
	margin-left: 25px;
	font-weight: bold;
      color: #2c3e50;
	}

#header_wrap .menu nav a.router-link-exact-active {
  color: #42b983;
}

#header_wrap .title {
	height: 80px;
	line-height: 80px;
	text-align: center;
	}
</style>